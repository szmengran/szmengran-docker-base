
/**
 * from org.springframework.core.env
 */
package com.taobao.arthas.core.env;
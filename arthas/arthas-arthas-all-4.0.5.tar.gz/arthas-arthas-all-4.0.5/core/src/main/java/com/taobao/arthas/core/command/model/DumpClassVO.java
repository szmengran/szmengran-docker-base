package com.taobao.arthas.core.command.model;

/**
 * Dumped class VO
 * @author gongdewei 2020/7/9
 */
public class DumpClassVO extends ClassVO {
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}

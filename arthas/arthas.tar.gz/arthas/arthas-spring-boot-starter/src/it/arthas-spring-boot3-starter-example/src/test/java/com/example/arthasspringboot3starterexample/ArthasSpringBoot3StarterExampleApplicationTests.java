package com.example.arthasspringbootstarterexample3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArthasSpringBoot3StarterExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

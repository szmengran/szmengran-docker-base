package com.hello;

import com.test.TestLogger1;

public class TestLogger2 extends TestLogger1 {

}

English README has been moved [here](README.md).

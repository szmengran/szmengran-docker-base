import { createApp } from "vue";
import App from "./Process.vue";
const app = createApp(App);
import "~/main.css";
app
  .mount("#app");

type NativeAgentInfo = {
  ip:string,
  httpPort:number,
  wsPort:number
}
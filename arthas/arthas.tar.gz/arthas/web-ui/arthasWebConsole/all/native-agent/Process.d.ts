type JavaProcessInfo = {
  processName:string,
  pid:number,
}
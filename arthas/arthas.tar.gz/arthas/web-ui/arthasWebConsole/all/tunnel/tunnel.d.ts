type AgentInfo = {
  clientConnectHost:string,
  host:string,
  port:number,
  clientConnectTunnelPort:number,
  arthasVersion:string
}
import App from "./Apps.vue"
import { createApp } from "vue"
import "~/main.css";
createApp(App)
  .mount("#app");
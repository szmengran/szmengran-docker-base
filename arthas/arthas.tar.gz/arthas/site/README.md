<h1>Arthas 文档网站<sub>(power by vuepress)</sub></h1>

## 项目运行

```shell
# 安装依赖
npm install

# 启动项目
npm run docs:dev

# 发布项目（打包到 docs/.vuepress/dist 目录）
npm run docs:build
```

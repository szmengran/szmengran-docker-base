# 联系我们

### 招聘

- [期待你的加入](https://mp.weixin.qq.com/s/XQv8GnqGT3pzceVwzeiy-A)

### Issues

使用疑问，意见可以直接在 Issues 里提出： [https://github.com/alibaba/arthas/issues](https://github.com/alibaba/arthas/issues)

### 微信公众号

欢迎关注公众号，获取 Arthas 项目的信息、源码分析、案例实践。

![](/images/qrcode_gongzhonghao.jpg)

### 钉钉群

- Arthas 开源交流钉钉群： 21965291 ，搜索群号即可加入。（如果满了无法加入，请加 4 群）

![](/images/dingding_qr.jpg)

- Arthas 开源交流钉钉群 2： 30707824 ，搜索群号即可加入。（如果满了无法加入，请加 4 群）

![](/images/dingding2_qr.jpg)

- Arthas 开源交流钉钉群 3： 17605006847 ，搜索群号即可加入。（如果满了无法加入，请加 4 群）

![](/images/dingding3_qr.jpg)

- Arthas 开源交流钉钉群 4： 41920010710 ，搜索群号即可加入。

![](/images/dingding4_qr.png)

### QQ 群

Arthas 开源交流 QQ 群： 916328269 （如果满了无法加入，请加 3 群）

![](/images/qqgroup_qr.jpg)

Arthas 开源交流 QQ 群 2： 854625984

![](/images/qqgroup2_qr.jpg)

Arthas 开源交流 QQ 群 3： 672077388

![](/images/qqgroup3_qr.jpg)

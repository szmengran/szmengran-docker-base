# stop

关闭 Arthas 服务端，所有 Arthas 客户端全部退出。

::: tip
关闭 Arthas 服务器之前，会重置掉所有做过的增强类。但是用 redefine 重加载的类内容不会被重置。
:::

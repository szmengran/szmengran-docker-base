# version

输出当前目标 Java 进程所加载的 Arthas 版本号

## 使用参考

```
$ version
 3.5.1
```

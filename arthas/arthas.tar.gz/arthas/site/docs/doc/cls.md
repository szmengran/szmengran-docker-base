# cls

清空当前屏幕区域。

::: tip
非终端模式下使用 cls 指令，会提示"Command 'cls' is only support tty session."。
:::

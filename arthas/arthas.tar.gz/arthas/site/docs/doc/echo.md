# echo

[`echo`在线教程](https://arthas.aliyun.com/doc/arthas-tutorials.html?language=cn&id=command-echo)

::: tip
打印参数，和 linux 里的 echo 命令类似。
:::

## 使用参考

```bash
$ echo 'hello'
```

# session

examines the current session,show the current binded processId and the sessionId.
::: tip
if exits tunnel server，it will also show agentId、tunnelServerUrl、connected status.

if exits statUrl，it will also show statUrl.
:::

## Usage

```bash
$ session
  Name        Value
--------------------------------------------------
 JAVA_PID    14584
 SESSION_ID  c2073d3b-443a-4a9b-9249-0c5d24a5756c
```

# cls

clear current console.

::: tip
if not in tty mode,it will warn "Command 'cls' is only support tty session.".
:::

# version

prints out Arthas's version.

## Usage

```bash
$ version
 3.5.1
```

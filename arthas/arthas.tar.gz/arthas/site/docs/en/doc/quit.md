# quit

exit the current Arthas client without affecting other clients. equals **exit**、**logout**、**q** command.

::: tip
just exit Arthas client,it means Arthas server is not closed,so the changes you do will not be reseted.
:::

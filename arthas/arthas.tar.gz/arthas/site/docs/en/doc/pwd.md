# pwd

[`pwd` online tutorial](https://arthas.aliyun.com/doc/arthas-tutorials.html?language=en&id=command-pwd)

::: tip
Return working directory name
:::

## Usage

```bash
$ pwd
```

# cat

[`cat` online tutorial](https://arthas.aliyun.com/doc/arthas-tutorials.html?language=en&id=command-cat)

::: tip
Concatenate and print files
:::

## Usage

```bash
$ cat /tmp/a.txt
```

# IDEA Plugin

::: tip
Plugin is provided by community developers.
:::

- Jetbrains Plugin： [https://plugins.jetbrains.com/plugin/13581-arthas-idea](https://plugins.jetbrains.com/plugin/13581-arthas-idea)
- Plugin Doc：[https://www.yuque.com/arthas-idea-plugin](https://www.yuque.com/arthas-idea-plugin)
- Plugin Github： [https://github.com/WangJi92/arthas-idea-plugin](https://github.com/WangJi92/arthas-idea-plugin)

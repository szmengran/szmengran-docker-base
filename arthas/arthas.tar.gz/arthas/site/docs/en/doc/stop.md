# stop

terminates the Arthas server, all the Arthas clients connecting to this server will be disconnected.

::: tip
the class redefined by redefine command will not be reset.
:::

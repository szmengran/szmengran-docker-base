# echo

[`echo` online tutorial](https://arthas.aliyun.com/doc/arthas-tutorials.html?language=en&id=command-echo)

::: tip
write arguments to the standard output.
:::

## Usage

```bash
$ echo 'hello'
```

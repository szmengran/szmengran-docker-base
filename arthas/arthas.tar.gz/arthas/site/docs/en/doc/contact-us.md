# Contact Us

### Issues

Questions about how to use Arthas and opinions can be directly raised in issues： [https://github.com/alibaba/arthas/issues](https://github.com/alibaba/arthas/issues)

### DingDing Group

- Arthas open source discussion Group： 21965291 ，You can join by searching for group number。

![](/images/dingding_qr.jpg)

- Arthas open source discussion Group 2： 30707824 ，You can join by searching for group number。

![](/images/dingding2_qr.jpg)

- Arthas open source discussion Group 3： 17605006847 , You can join by searching for group number。

![](/images/dingding3_qr.jpg)

- Arthas open source discussion Group 4： 41920010710 , You can join by searching for group number。

![](/images/dingding4_qr.png)

### Instructions for Installing DingTalk

DingTalk can be downloaded from: [https://www.dingtalk.com/en](https://page.dingtalk.com/wow/dingtalk/act/en-download)

After installing you can search for group number and join it.

![](/images/dingding_group_search.png)

### QQ Group

Arthas open source discussion QQ group：916328269

![](/images/qqgroup_qr.jpg)

Arthas open source discussion QQ group2：854625984

Arthas open source discussion QQ group 3： 672077388

![](/images/qqgroup3_qr.jpg)
